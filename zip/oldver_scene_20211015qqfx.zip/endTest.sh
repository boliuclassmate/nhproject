#!/bin/sh
echo "adb devices"
adb devices
