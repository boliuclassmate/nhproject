## 功能
对用户标记录制好的脚本进行回放

## 通信协议（参考http）
-> header

-> header

-> empty line separator

-> body

header中关键以及必须的关键字如下:
> body-size: body部分的字节数， 目前来看只需要body-size就行了， 其它的通过body中的数据去指定

body可以为任意数据， 但是最好写成JSON形式， 便于程序解析
> eg.
```javascript
{
    command:xxx,            //指令名称
    msg_identifier:xxxx,    //此条消息的唯一id， 用于标志已经发送过的，等待回复的消息，如果不需要回复可以不设置
    params:{}               //命令所需要的参数
}
```

### 指令
- 暂停        pause
- 继续        resume
- 回放程序准备就绪  ready-client
- 标记        mark
    - 标记特征      mark-feature        标记当前场景已经识别到的特征
    - 标记操作      mark-operation      标记将要进行的操作

- 遍历        traverse    告知当前遍历的场景
- 调试        debug-*     调试子功能
    - debug-add-scene
    - debug-remove-scene
    - debug-choose-object
    - debug-break-point

> body-size: body部分的字节数


## 想法
可以根据预期场景等待， 如果发现场景不是预期场景则等待或重复确认


# 二期规划
将回放作为一个整体设计， 包括几个模块

- 遍历算法实现
- 记录器， 记录执行的关键过程，包括遍历场景， 进行的操作
- 操作执行单元， 负责执行具体的操作对象指定的操作
- 未知场景处理单元，负责未知场景的处理
- 管理类，负责核心模块的管理，每个模块之间通过管理类来进行交互
