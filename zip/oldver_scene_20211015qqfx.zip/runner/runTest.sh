#!/usr/bin/env bash
export ET_WORKSPACE=.
export LOG_DIR=.
python ./runner/run.py -r ./script