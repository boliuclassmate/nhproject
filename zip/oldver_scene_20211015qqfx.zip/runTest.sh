#!/usr/bin/env bash
#!/bin/sh

echo $LD_LIBRARY_PATH
env
python3 ./runner/run_probe.pyc -r ./script -m wetest -t 60 -v